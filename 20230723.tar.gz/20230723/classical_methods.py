import sys
import networkx as nx
from itertools import combinations

def to_half_directed(G, node_ids):
    """
    完全N部無向グラフGから、頂点構造情報node_idsにおける
    index増加方向（ex. node_ids[0] -> node_ids[1]）のみ
    辺が存在する有向グラフを作成し、返す。
    なお一部手法のために辺の重みを1000倍して整数化している。
    """
    new_G = nx.DiGraph()
    for i in range(len(node_ids)-1):
        for node1 in node_ids[i]:
            for node2 in node_ids[i+1]:
                new_G.add_edge(node1, node2, weight=int(G[node1][node2]['weight']*1000))
    return new_G

def calc_min_cost_flow(G, nodes1, nodes2, y):
    """
    完全二部グラフの最小2マッチング問題を最小費用流問題に
    帰着させて解く。
    """
    subG = G.subgraph(nodes1+nodes2)
    for n1 in nodes1:
        nx.set_node_attributes(subG, {n1:{"demand":-y}})
    for n2 in nodes2:
        nx.set_node_attributes(subG, {n2:{"demand":y}})
    nx.set_edge_attributes(subG, 1, "capacity")
    flow_dict = nx.min_cost_flow(subG)
    
    cost = 0
    for e1 in flow_dict:
        for e2 in flow_dict[e1]:
            if flow_dict[e1][e2]:
                cost += G[e1][e2]["weight"]
    return cost

def sub_run_0(G, node_ids, start_node, terminal_nodes, x, y):
    cost = 0
    nodes1 = []
    # 最初のホップ
    sorted_first_edges = sorted(G[start_node].items(), key=lambda item: item[1]["weight"])
    for i in range(x):
        cost += sorted_first_edges[i][1]["weight"]
        nodes1.append(sorted_first_edges[i][0])
    
    # 中間のホップ
    for i in range(1, len(node_ids)-3):
        min_cost = sys.maxsize
        min_nodes = []
        for comb in combinations(node_ids[i+1], x):
            temp_cost = calc_min_cost_flow(G, nodes1, list(comb), y)
            if temp_cost < min_cost:
                min_cost = temp_cost
                min_nodes = list(comb)
        cost += min_cost
        nodes1 = min_nodes

    # 最後のホップ。終点に至るまでの重みも含めて最良を選択
    min_cost = sys.maxsize
    for comb in combinations(node_ids[-2], x):
        temp_cost = calc_min_cost_flow(G, nodes1, list(comb), y)
        for n1 in list(comb):
            for n2 in terminal_nodes:
                temp_cost += G[n1][n2]["weight"]
        if temp_cost < min_cost:
            min_cost = temp_cost
    cost += min_cost
    return cost

def sub_run_1(G, node_ids, start_node, terminal_nodes, x, y):
    cost = 0
    nodes1 = []
    # 最初のホップ
    sorted_first_edges = sorted(G[start_node].items(), key=lambda item: item[1]["weight"])
    for i in range(x):
        cost += sorted_first_edges[i][1]["weight"]
        nodes1.append(sorted_first_edges[i][0])
    
    # 中間のホップ
    for i in range(1, len(node_ids)-3):
        min_cost, min_nodes = get_flow_selecting_min_weight(G, nodes1, node_ids[i+1], y)
        cost += min_cost
        nodes1 = min_nodes

    # 最後のホップ。終点に至るまでの重みも含めて最良を選択
    min_cost, min_nodes = get_flow_selecting_min_weight(G, nodes1, node_ids[-2], y)
    cost += min_cost
    for n1 in min_nodes:
        for n2 in terminal_nodes:
            cost += G[n1][n2]["weight"]
    return cost

def run(G, node_ids, start_node, terminal_nodes, x, y, solver):
    """
    Parameters
    ---
    G : networkx.classes.graph.Graph
        経路探索対象の無向グラフ
    node_ids : list[list[int]]
        無向グラフGの頂点構造情報を格納したリスト
    start_node : int
        始点ノード
    terminal_nodes : list[int]
        終点ノード群
    x : int
        分散数
    y : int
        中間ノードにおける入力辺数および出力辺数
    solver : int
        適用する古典解法ID
        0:貪欲法。各ホップにおいて全ての組み合わせに対し最小yマッチングを
          最小費用流問題に帰着させて解く。
        1:貪欲法。各ホップにおける最小yマッチングを
          線形計画法により解く。
        2:日本地図にも適用した線形計画法で解く。
        3:N部グラフ用の線形計画法で解く。
    Returns
    ---
    cost : 探索された経路の重み
    """

    diG = to_half_directed(G, node_ids)

    if solver == 0:
        return sub_run_0(diG, node_ids, start_node, terminal_nodes, x, y) / 1000
    elif solver == 1:
        return sub_run_1(diG, node_ids, start_node, terminal_nodes, x, y) / 1000
    elif solver == 2:
        pass
    elif solver == 3:
        pass
    return 0

if __name__ == "__main__":
    pass