import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# 頂点座標の取得
def get_pos(node_list):
    pos = []
    dx = 1.0 / (len(node_list) - 1)
    for x_ind in range(len(node_list)):
        dy = 1.0 / (node_list[x_ind] + 1)
        for y_ind in range(node_list[x_ind]):
            pos.append((x_ind * dx, y_ind * dy + dy))
    return pos

# 頂点の色取得
def get_color_map(G, start_nodes, terminal_nodes):
    color_map = []
    for node in G:
        if node in start_nodes:
            color_map.append('lightblue')
        elif node in terminal_nodes:
            color_map.append('pink')
        else:
            color_map.append('yellow')
    return color_map

# グラフ描画
def draw_graph(G, pos, start_nodes, terminal_nodes):
    plt.figure(figsize=(10,6))
    color_map = get_color_map(G, start_nodes, terminal_nodes)
    edge_labels = {(i,j):w['weight'] for i,j,w in G.edges(data=True)}

    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)
    nx.draw_networkx(G, pos, with_labels=True, node_color=color_map)
    plt.show()

# ランダムな無向グラフの作成
def generate_graph(node_list, seed, ave, stdev, start_nodes, terminal_nodes):
    np.random.seed(seed)

    N = sum(node_list)
    current_node_id = 0
    node_ids = [[] for i in range(len(node_list))]
    for i in range(len(node_list)):
        for j in range(node_list[i]):
            node_ids[i].append(current_node_id)
            current_node_id += 1

    pos = get_pos(node_list)
    edges = []
    e_num = (len(node_list) - 1) * node_list[0] * node_list[0]
    rng = np.random.default_rng(seed)
    edge_weight = rng.normal(ave, stdev, e_num)
    counter = 0
    for i in range(len(node_ids) - 1):
        for node1 in node_ids[i]:
            for node2 in node_ids[i + 1]:
                edges.append([node1, node2, round(edge_weight[counter], 3)]) # 辺の重みは小数点第三位
                counter += 1

    G = nx.Graph()
    G.add_nodes_from([i for i in range(N)])
    G.add_weighted_edges_from(edges)

    return G, pos, node_ids

if __name__ == "__main__":
    pass
